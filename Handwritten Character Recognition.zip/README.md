# Handwriting_detection
Optical Character Recognition (OCR) is the process that converts an image of text into a machine-readable text format. 
For example, if you scan a form or a receipt, your computer saves the scan as an image file
